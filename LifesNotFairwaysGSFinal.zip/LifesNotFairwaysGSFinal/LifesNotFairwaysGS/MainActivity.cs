﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;
using Android.Content;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "LifesNotFairwaysGS", MainLauncher = true)]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            FindViewById<Button>(Resource.Id.btnmembers).Click += BtnMembers_Click;
            FindViewById<Button>(Resource.Id.btnevents).Click += BtnGolfCourses_Click;
            FindViewById<Button>(Resource.Id.btnresults).Click += BtnResults_Click;
        }

        private void BtnMembers_Click(object sender, System.EventArgs e)
        {
            Intent membersIntent = new Intent(this, typeof(MembersListActivity));
            StartActivity(membersIntent);
        }

        private void BtnGolfCourses_Click(object sender, EventArgs e)
        {
            Intent coursesIntent = new Intent(this, typeof(GolfCourseListActivity));
            StartActivity(coursesIntent);
        }

        private void BtnResults_Click(object sender, EventArgs e)
        {
            Intent resultsIntent = new Intent(this, typeof(ResultsListActivity));
            StartActivity(resultsIntent);
        }
    }
}

