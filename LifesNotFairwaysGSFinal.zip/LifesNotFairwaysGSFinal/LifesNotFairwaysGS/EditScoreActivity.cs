﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "EditScoreActivity")]
    public class EditScoreActivity : Activity
    {       
        TextView txtName;
        EditText txtScore;
        DBStore dbStore;
        int ID;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.editscoreslayout);

            Title = Intent.GetStringExtra(GetString(Resource.String.golfcourse));

            txtName = FindViewById<TextView>(Resource.Id.txtName);
            txtName.Text = Intent.GetStringExtra(GetString(Resource.String.name));
            txtScore = FindViewById<EditText>(Resource.Id.txtscore);
            txtScore.Text = Intent.GetStringExtra(GetString(Resource.String.score));
            ID = int.Parse(Intent.GetStringExtra(GetString(Resource.String.id)));

            FindViewById<Button>(Resource.Id.btnCancel).Click += (s, e) => { Finish(); };

            FindViewById<Button>(Resource.Id.btnSaveChanges).Click += BtnSave_Click;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                Outings updateScore = new Outings();
                updateScore.ID = ID;
                updateScore.EventID = int.Parse(Intent.GetStringExtra(GetString(Resource.String.eventID)));
                updateScore.GolfCourse = Intent.GetStringExtra(GetString(Resource.String.golfcourse));
                updateScore.Player = txtName.Text;
                updateScore.Handicap = int.Parse(Intent.GetStringExtra(GetString(Resource.String.handicaphint)));
                updateScore.Score = int.Parse(txtScore.Text);

                //adding the updated score to the database
                dbStore = new DBStore();
                dbStore.UpdateOuting(updateScore);

                //sending the updates back to the Outing list of players
                Intent returnUpdates = new Intent();
                returnUpdates.PutExtra(GetString(Resource.String.id), updateScore.ID.ToString());
                returnUpdates.PutExtra(GetString(Resource.String.name), updateScore.Player);
                returnUpdates.PutExtra(GetString(Resource.String.handicaphint), updateScore.Handicap.ToString());
                returnUpdates.PutExtra(GetString(Resource.String.score), updateScore.Score.ToString());

                SetResult(Result.Ok, returnUpdates);

                Finish();
            }
            else
            {
                Toast.MakeText(this, "Input error, no changes saved", ToastLength.Short).Show();
                Finish();
            }
        }

        private bool ValidateInput()
        {
            bool isvalid = true;
            if (!int.TryParse(txtScore.Text, out int validscore))
            {
                isvalid = false;
            }
            return isvalid;
        }
    }
}