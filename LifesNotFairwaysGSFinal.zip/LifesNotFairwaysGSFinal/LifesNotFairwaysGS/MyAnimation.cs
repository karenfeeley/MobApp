﻿using Android.Views;
using Android.Views.Animations;

namespace LifesNotFairwaysGS
{
    class MyAnimation : Animation
    {
        private View mView;
        private int mOriginalHeight;
        private int mTargetHeight;
        private int mGrowby;

        public MyAnimation(View view, int targetHeight)
        {
            mView = view;
            mOriginalHeight = view.Height;
            mTargetHeight = targetHeight;
            mGrowby = mTargetHeight - mOriginalHeight;
        }

        //setting the layout parameters and we are animating the height
        protected override void ApplyTransformation(float interpolatedTime, Transformation t)
        {
            mView.LayoutParameters.Height = (int)(mOriginalHeight + (mGrowby * interpolatedTime));
            mView.RequestLayout();
        }

        public override bool WillChangeBounds()
        {
            return true;
        }
    }
}