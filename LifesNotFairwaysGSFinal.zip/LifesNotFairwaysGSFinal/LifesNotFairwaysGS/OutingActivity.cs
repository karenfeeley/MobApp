﻿using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "OutingActivity")]
    public class OutingActivity : Activity
    {
        ListView lvOutings;
        static List<Outings> OutingsList;
        static List<Member> MemberList;
        DBStore dbStore;
        TextView txtcourseTitle;
        int outingEventId;
        Button btnSave;
        public List<string> Players;
        TextView txtscore;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            
            SetContentView(Resource.Layout.Outinglayout);
            lvOutings = FindViewById<ListView>(Resource.Id.lvOutings);
            //setup and call the database
            dbStore = new DBStore();
            outingEventId = int.Parse(Intent.GetStringExtra("EventID"));
            string golfcourse = Intent.GetStringExtra("GolfCourse");
            txtcourseTitle = FindViewById<TextView>(Resource.Id.txtCourseTitle);
            txtcourseTitle.Text = golfcourse;
            txtscore = FindViewById <EditText>(Resource.Id.txtscore);

            btnSave = FindViewById<Button>(Resource.Id.btnSaveChanges);
         
            IEnumerable<Outings> dboutings = dbStore.GetOutings(outingEventId);
            OutingsList = dboutings.ToList();       

            if (dboutings.Count() == 0)
            {
                btnSave.Visibility = ViewStates.Visible;
                Toast.MakeText(this, "Select players to add to outing", ToastLength.Short).Show();
                IEnumerable<Member> dbmembers = dbStore.GetMembers();
                MemberList = dbmembers.ToList();
                Players = new List<string>();
                foreach (var player in dbmembers)//adding members list to players for selection
                {
                    Players.Add(player.Name);
                }
                lvOutings.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItemMultipleChoice, Players);
                lvOutings.ChoiceMode = ChoiceMode.Multiple;

                btnSave.Click += (s, e) =>
                    {
                        var selectedItems = FindViewById<ListView>(Resource.Id.lvOutings).CheckedItemPositions;
                        int score = 0;
                        
                        dbStore = new DBStore();

                        for (int i = 0; i < selectedItems.Size(); i++)
                        {
                            int position = selectedItems.KeyAt(i);
                            dbStore.AddOutings(outingEventId, golfcourse,MemberList[position].Name, MemberList[position].Handicap, score);
                        }
                        Finish();
                    };          
            }
            else
            {
                OutingsList = dboutings.ToList();
                //assign the adapter
                lvOutings.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, OutingsList);
                lvOutings.ChoiceMode = ChoiceMode.Single;
                
                lvOutings.ItemClick += Edit_Item_Click;             
            }   
        }//end of oncreate method

        private void Edit_Item_Click(object sender, AdapterView.ItemClickEventArgs e)
        {
            int p = e.Position;
            Intent edit_scoreIntent = new Intent(this, typeof(EditScoreActivity));
            edit_scoreIntent.PutExtra(GetString(Resource.String.id), OutingsList[p].ID.ToString());
            edit_scoreIntent.PutExtra(GetString(Resource.String.eventID), OutingsList[p].EventID.ToString());
            edit_scoreIntent.PutExtra(GetString(Resource.String.golfcourse), OutingsList[p].GolfCourse);
            edit_scoreIntent.PutExtra(GetString(Resource.String.name), OutingsList[p].Player);
            edit_scoreIntent.PutExtra(GetString(Resource.String.handicaphint), OutingsList[p].Handicap.ToString());
            edit_scoreIntent.PutExtra(GetString(Resource.String.score), OutingsList[p].Score.ToString());
            
            StartActivityForResult(edit_scoreIntent, 100);
        }

        protected override void OnActivityResult(int requestCode, [GeneratedEnum] Result resultCode, Intent data)
        {
            if (resultCode == Result.Ok && requestCode == 100)
            {
                int ID = int.Parse(data.GetStringExtra(GetString(Resource.String.id)));
                Outings updateScore = OutingsList.Find(m => m.ID == ID);
                updateScore.Player = data.GetStringExtra(GetString(Resource.String.name));
                updateScore.Handicap = int.Parse(data.GetStringExtra(GetString(Resource.String.handicaphint)));
                updateScore.Score = int.Parse(data.GetStringExtra(GetString(Resource.String.score)));

                lvOutings.Adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, OutingsList);             
            }
        }

    }
}