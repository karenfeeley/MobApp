﻿using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using LifesNotFairwaysGS.Adapters;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "GolfCoursesListActivity")]
    public class GolfCourseListActivity : Activity
    {
        ListView lvGolfCourses;
        static List<GolfCourses> CourseList;
        DBStore dbStore;
        GolfCourseListAdapter adapter;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            //setup and call the database
            dbStore = new DBStore();
            IEnumerable<GolfCourses> dbcourses = dbStore.GetCourses();
            //assign the database data to the list
            CourseList = dbcourses.ToList();

            // Create your application here
            SetContentView(Resource.Layout.GolfCourselayout);

            lvGolfCourses = FindViewById<ListView>(Resource.Id.lvGolfCourses);

            //assign the adapter
            adapter = new GolfCourseListAdapter(this, CourseList);
            lvGolfCourses.Adapter = adapter;

            //listitem click event -adding players or seeing existing players
            lvGolfCourses.ItemClick += Course_ItemClick;
            //longitem click - directions & websites
            lvGolfCourses.ItemLongClick += Course_ItemLongClick;
        }

        private void Course_ItemLongClick(object sender, AdapterView.ItemLongClickEventArgs e)
        {
            var gc = CourseList[e.Position];
            var popupmenu = new PopupMenu(this, e.View);
            popupmenu.Inflate(Resource.Menu.coursepopupmenu);

            popupmenu.MenuItemClick += (s, m) =>
            {
                switch (m.Item.ItemId)
                {
                    case Resource.Id.mnuShowMap:
                        Android.Net.Uri googleMapsUri = Android.Net.Uri.Parse(gc.GolfGeoLocation);
                        Intent googleMapIntent = new Intent(Intent.ActionView, googleMapsUri);
                        StartActivity(googleMapIntent);
                        break;
                    case Resource.Id.mnuShowWebsite:
                        Intent webintent = new Intent(Intent.ActionView, Android.Net.Uri.Parse(gc.GolfWebSite));
                        StartActivity(webintent);
                        break;

                    default:
                        break;
                }
            };
            popupmenu.Show();
        }

        private void Course_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            var gc = CourseList[e.Position];
            Intent outingIntent = new Intent(this, typeof(OutingActivity));
            outingIntent.PutExtra("EventID", gc.EventID.ToString());
            outingIntent.PutExtra("GolfCourse", gc.GolfCourse);
            StartActivity(outingIntent);
        }
    }
}