﻿using System;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;

namespace LifesNotFairwaysGS
{
    public class CreateMemberEventArgs : EventArgs
    {
        public string Name { get; set; }
        public int Number { get; set; }
        public string Email { get; set; }
        public int Handicap { get; set; }

        public CreateMemberEventArgs(string name, int number, string email, int handicap)
        {
            Name = name;
            Number = number;
            Email = email;
            Handicap = handicap;
        }
    }

    public class CreateMemberDialog : DialogFragment
    {
        EditText txtName;
        EditText txtPhone;
        EditText txtEmail;
        EditText txtHandicap;

        public event EventHandler<CreateMemberEventArgs> OnCreateMember;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {

            base.OnCreateView(inflater, container, savedInstanceState);

            var view = inflater.Inflate(Resource.Layout.dialog_addmember, container, false);

            txtName = view.FindViewById<EditText>(Resource.Id.txtdlgName);
            txtPhone = view.FindViewById<EditText>(Resource.Id.txtdlgNumber);
            txtEmail = view.FindViewById<EditText>(Resource.Id.txtdlgEmail);
            txtHandicap = view.FindViewById<EditText>(Resource.Id.txtdlgHandicap);
            view.FindViewById<Button>(Resource.Id.btnCreateMember).Click += BtnCreateMember_Click;  

            return view;

        }

        private void BtnCreateMember_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                OnCreateMember.Invoke(this, new CreateMemberEventArgs(txtName.Text, int.Parse(txtPhone.Text), txtEmail.Text, int.Parse(txtHandicap.Text)));

                Toast.MakeText(Activity, "New Member added", ToastLength.Short).Show();
                this.Dismiss();
            }
            else
            {
                Toast.MakeText(Activity, "Input errors", ToastLength.Short).Show();
            }
   
        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            Dialog.Window.RequestFeature(WindowFeatures.NoTitle);//gets rid of dialog title
            base.OnActivityCreated(savedInstanceState);
            Dialog.Window.Attributes.WindowAnimations = Resource.Style.dialog_animation;
        }

        private bool ValidateInput()
        {
            bool isvalid = true;

            if (string.IsNullOrEmpty(txtName.Text))
            {
               isvalid = false;
            }
            if (string.IsNullOrEmpty(txtPhone.Text))
            {
                isvalid = false;
            }
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
               isvalid = false;
            }
            if (string.IsNullOrEmpty(txtHandicap.Text))
            {
               isvalid = false;
            }
            if (!int.TryParse(txtPhone.Text, out int validnumber))
            {
                isvalid = false;
            }
            if (!CheckEmail(txtEmail.Text))
            {
               isvalid = false;
            }
            if (!int.TryParse(txtHandicap.Text, out int validinput))
            {
               isvalid = false;
            }
            return isvalid;
        }

        private bool CheckEmail(string email)
        { 
            return Android.Util.Patterns.EmailAddress.Matcher(email).Matches();
        }
    }
}