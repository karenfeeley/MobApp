﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "Edit_Del_MembersActivity")]
    public class Edit_Del_MembersActivity : Activity
    {
        EditText txtname;
        EditText txtphone;
        EditText txtemail;
        EditText txthandicap;
        string memberID;
        DBStore dbStore;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            //set the layout 
            SetContentView(Resource.Layout.edit_del_memlayout);
            //assign the variables
            txtname = FindViewById<EditText>(Resource.Id.txtName);
            txtname.Text = Intent.GetStringExtra(GetString(Resource.String.name));
            txtphone = FindViewById<EditText>(Resource.Id.txtPhone);
            txtphone.Text = Intent.GetStringExtra(GetString(Resource.String.phoneheader));
            txtemail = FindViewById<EditText>(Resource.Id.txtEmail);
            txtemail.Text = Intent.GetStringExtra(GetString(Resource.String.emailheader));
            txthandicap = FindViewById<EditText>(Resource.Id.txtHandicap);
            txthandicap.Text = Intent.GetStringExtra(GetString(Resource.String.handicaphint));
            memberID = Intent.GetStringExtra(GetString(Resource.String.id));

            FindViewById<Button>(Resource.Id.btnCancel).Click += (s, e) => { Finish(); };

            FindViewById<Button>(Resource.Id.btnSaveChanges).Click += BtnSave_Click;
           
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {

            if (ValidateInput())
            {
                Member updatemember = new Member();
                updatemember.MemberID = int.Parse(memberID);
                updatemember.Name = txtname.Text;
                updatemember.Phone = int.Parse(txtphone.Text);
                updatemember.Email = txtemail.Text;
                updatemember.Handicap = int.Parse(txthandicap.Text);

                dbStore = new DBStore();
                dbStore.UpdateMember(updatemember);

                Intent returnUpdates = new Intent();
                returnUpdates.PutExtra(GetString(Resource.String.id), updatemember.MemberID.ToString());
                returnUpdates.PutExtra(GetString(Resource.String.name), updatemember.Name);
                returnUpdates.PutExtra(GetString(Resource.String.phoneheader), updatemember.Phone.ToString());
                returnUpdates.PutExtra(GetString(Resource.String.emailheader), updatemember.Email);
                returnUpdates.PutExtra(GetString(Resource.String.handicaphint), updatemember.Handicap.ToString());

                SetResult(Result.Ok, returnUpdates);

                Finish();
            }
            else
            {
                Toast.MakeText(this, "Input errors, no changes saved", ToastLength.Short).Show();
            }
            
            Finish();
        }

        private bool ValidateInput()
        {
            bool isvalid = true;
            if (!int.TryParse(txtphone.Text, out int validphone))
            {
                isvalid = false;
            }
            if (!CheckEmail(txtemail.Text))
            {
                isvalid = false;
            }
            if (!int.TryParse(txthandicap.Text, out int validhc))
            {
                isvalid = false;
            }
            return isvalid;
        }

        private bool CheckEmail(string email)
        {
            return Android.Util.Patterns.EmailAddress.Matcher(email).Matches();
        }
    }
}