﻿using SQLite;

namespace LifesNotFairwaysGS.DataAccess
{
    [Table("Member")]
    public class Member
    {
        [PrimaryKey, AutoIncrement]
        public int MemberID { get; set; }
        public string Name { get; set; }
        public int Phone { get; set; }
        public string Email { get; set; }
        public int Handicap { get; set; }

        public Member(string name, int phone, string email, int handicap)
        {
            Name = name;
            Phone = phone;
            Email = email;
            Handicap = handicap;
        }

        //default constructor required for Data Access
        public Member()
        {

        }

    }
}