﻿using SQLite;


namespace LifesNotFairwaysGS.DataAccess
{
    [Table("Outings")]

    public class Outings
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public int EventID { get; set; }
        public string GolfCourse { get; set; }
        public string Player { get; set; }
        public  int Handicap { get; set; }
        public int Score { get; set; }

        public Outings()
        {

        }
        public Outings(int eventID, string golfcourse, string players, int handicap, int score)
        {
            EventID = eventID;
            GolfCourse = golfcourse;
            Player = players;
            Handicap = handicap;
            Score = score;
           
        }

        public override string ToString()
        {
            return $"{Player}, Handicap: {Handicap}, Score: {Score}"; 
        }
    }
}