﻿using System;
using System.Collections.Generic;
using Android.App;
using SQLite;
using System.IO;

namespace LifesNotFairwaysGS.DataAccess
{
    class DBStore
    {
        public static string DBFilepath { get; }
        static List<GolfCourses> CourseList;

        static DBStore()
        {

            if (string.IsNullOrEmpty(DBFilepath))
            {
                DBFilepath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "LNFGS.db3");

                InitialiseMembers();
                InitialiseGolfCourses();
                InitialiseOutings();
                   
            }
        }

        private static void InitialiseOutings()
        {
            try
            {
                 //setup table in database
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    cxn.DropTable<Outings>();
                    cxn.CreateTable<Outings>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        private static void InitialiseGolfCourses()
        {
            try
            {
                //read in list of events from textfile
                CourseList = new List<GolfCourses>();
                char[] separator1 = { '|' };
                using (var fs = Application.Context.Assets.Open("GolfCourses.txt"))
                {
                    using (StreamReader reader = new StreamReader(fs))
                    {
                        while (reader.Peek() > -1)
                        {
                            string data = reader.ReadLine();
                            string[] splitfile = data.Split(separator1);
                            GolfCourses courses = new GolfCourses(splitfile[0].Trim(), splitfile[1].Trim(), splitfile[2].Trim(), splitfile[3].Trim());

                            CourseList.Add(courses);
                        }
                    }
                }

                //setup table in database
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    cxn.DropTable<GolfCourses>();
                    cxn.CreateTable<GolfCourses>();
                    TableQuery<GolfCourses> tableQuery = cxn.Table<GolfCourses>();
                    if (tableQuery.Count() == 0)
                    {
                        foreach (GolfCourses outing in CourseList)
                        {
                            cxn.Insert(outing);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }           
        }

        private static void InitialiseMembers()
        {
            try
            {
                //read in list of members from textfile
               List<Member> MembersList = new List<Member>();
                char[] separator = { ',' };
                using (var fs = Application.Context.Assets.Open("LNFMembers.txt"))
                {
                    using (StreamReader reader = new StreamReader(fs))
                    {
                        while (reader.Peek() > -1)
                        {
                            string line = reader.ReadLine();
                            string[] splitline = line.Split(separator);
                            Member member = new Member(splitline[0].Trim(), int.Parse(splitline[1].Trim()), splitline[2].Trim(), int.Parse(splitline[3].Trim()));
                            MembersList.Add(member);
                        }
                    }
                }

                //setup table in database
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    cxn.DropTable<Member>();  

                    cxn.CreateTable<Member>();
                    TableQuery<Member> query = cxn.Table<Member>();
                    if (query.Count() == 0)
                    {
                        foreach (Member person in MembersList)
                        {
                            cxn.Insert(person);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to call the member details in the Members table
        public IEnumerable<Member> GetMembers()
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    IEnumerable<Member> members = cxn.Query<Member>("SELECT * FROM Member");
                    return members;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to call the outing results 
        public IEnumerable<Outings> GetResults()
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    IEnumerable<Outings> results = cxn.Query<Outings>("SELECT * FROM Outings");
                    return results;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to call the outing details in the Outings table
        public IEnumerable<Outings> GetOutings(int eventID)
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    IEnumerable<Outings> outings = cxn.Query<Outings>("SELECT * FROM Outings Where EventID = ?", eventID);
                     
                    return outings;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to add players to outings
        public void AddOutings(int eventID, string course,string players, int handicap, int score)
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    Outings updateOuting = new Outings(eventID, course, players, handicap, score);
                    cxn.Insert(updateOuting);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to update outing scores
        public void UpdateOuting(Outings outing)
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {

                    cxn.Update(outing);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
        //method to call the GolfCourses details in the GolfCourses table
        public IEnumerable<GolfCourses> GetCourses()
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    IEnumerable<GolfCourses> courses = cxn.Query<GolfCourses>("SELECT * FROM GolfCourses");
                    return courses;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }


        //method to add new member details
        public void AddMember(string name, int phone, string email, int handicap)
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                    Member newmember = new Member(name, phone, email, handicap);
                    cxn.Insert(newmember);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to update member details
        public void UpdateMember(Member member)
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {
                   
                    cxn.Update(member);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //method to delete member details
        public void DeleteMember(Member member)
        {
            try
            {
                using (SQLiteConnection cxn = new SQLiteConnection(DBFilepath))
                {

                    cxn.Delete(member);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}