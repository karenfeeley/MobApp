﻿using SQLite;

namespace LifesNotFairwaysGS.DataAccess
{

    [Table("GolfCourses")]
    public class GolfCourses
    {
        [PrimaryKey, AutoIncrement]
        public int EventID { get; set; }
        public string GolfCourse { get; set; }
        public string GolfWebSite { get; set; }
        public string GolfGeoLocation { get; set; }
        public string EventDate { get; set; }
        

        public GolfCourses()//default constructor required for DataAccess
        {

        }
        public GolfCourses(string course, string website, string loc, string date)
        {
            GolfCourse = course;
            GolfWebSite = website;
            GolfGeoLocation = loc;
            EventDate = date;
           
        }

    }
}