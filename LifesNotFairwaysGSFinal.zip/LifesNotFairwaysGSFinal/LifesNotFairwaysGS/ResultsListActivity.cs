﻿using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.OS;
using Android.Widget;
using LifesNotFairwaysGS.Adapters;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "ResultsListActivity")]
    public class ResultsListActivity : Activity
    {
        ListView lvResults;
        List<Outings> ResultsList;
        DBStore dbStore = new DBStore();
        ResultsAdapter adapter;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.ResultListlayout);
            lvResults = FindViewById<ListView>(Resource.Id.lvResults);

            IEnumerable<Outings> results = dbStore.GetResults();
            ResultsList = results.ToList();
            if (ResultsList.Count == 0)
            {
                Toast.MakeText(this, "No results entered, please select Golf Events and add players and scores", ToastLength.Long).Show();
                Finish();
            }
            else
            {
                adapter = new ResultsAdapter(this, ResultsList);
                lvResults.Adapter = adapter;
            }
        }
    }
}