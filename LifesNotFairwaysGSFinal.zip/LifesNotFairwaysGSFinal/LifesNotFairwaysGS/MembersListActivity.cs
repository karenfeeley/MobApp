﻿using System;
using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Text;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    [Activity(Label = "MembersListActivity")]
    public class MembersListActivity : Activity
    {
        ListView memberslistView;
        static List<Member> MemberList;
        MemberListAdapter adapter;
        EditText txtSearch;
        TextView txtNameHeader;
        TextView txtPhoneHeader;
        TextView txtEmailHeader;
        LinearLayout container;
        DBStore dbStore = new DBStore();      

        bool NameAscending;
        bool PhoneAscending;
        bool EmailAscending;
        bool mIsAnimating;
        bool mAnimatedDown;
       

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            //setup and call the database
            IEnumerable<Member> dbmembers = dbStore.GetMembers();
            //assign the database data to the list
            MemberList = dbmembers.ToList();

           //set the layout
            SetContentView(Resource.Layout.Member_Contact);

            //assign the listview & headers in the layout
            memberslistView = FindViewById<ListView>(Resource.Id.lvMemberContact);
            txtSearch = FindViewById<EditText>(Resource.Id.txtSearch);
            txtNameHeader = FindViewById<TextView>(Resource.Id.txtNameHeader);
            txtPhoneHeader = FindViewById<TextView>(Resource.Id.txtPhoneHeader);
            txtEmailHeader = FindViewById<TextView>(Resource.Id.txtEmailHeader);
            container = FindViewById<LinearLayout>(Resource.Id.llContainer);

            //inflate the toolbar with the actionbar and assigning the mnuItems
            Toolbar tb = FindViewById<Toolbar>(Resource.Id.tbLifesNotFairways);
            //inflate the toolbar with the actions
            tb.InflateMenu(Resource.Menu.actionbar);
            IMenuItem mnuSearch = tb.Menu.FindItem(Resource.Id.search);
            IMenuItem mnuAdd = tb.Menu.FindItem(Resource.Id.add);
            tb.MenuItemClick += OnMenuItem_Click;

            //clickevents for headers
            txtNameHeader.Click += TxtNameHeader_Click;
            txtPhoneHeader.Click += TxtPhoneHeader_Click;
            txtEmailHeader.Click += TxtEmailHeader_Click;

            txtSearch.Alpha = 0;
            container.BringToFront(); //allows the header container to have focus instead of the EditText
            //subscribe to a textchange event
            txtSearch.TextChanged += Search_TextChanged;

            //assign the adapter
            adapter = new MemberListAdapter(this, MemberList);
            memberslistView.Adapter = adapter;

            //listitem click event
           memberslistView.ItemClick += Edit_ItemClick;
            //longitem click
            memberslistView.ItemLongClick += Delete_ItemClick;
            
        }

        private void Delete_ItemClick(object sender, AdapterView.ItemLongClickEventArgs e)
        {
            int position = e.Position;
            Member deletemember = new Member();
            deletemember.MemberID = MemberList[position].MemberID;
            deletemember.Name = MemberList[position].Name;

            //set alert for executing the task
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.SetTitle("Confirm deletion");
           alert.SetMessage($"{deletemember.Name} will be deleted.");
            alert.SetPositiveButton("Delete", (senderAlert, args) => 
            {
                
                dbStore = new DBStore();
                dbStore.DeleteMember(deletemember);
                IEnumerable<Member> dbmembers = dbStore.GetMembers();
                //assign the database data to the list
                MemberList = dbmembers.ToList();
                adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;

                Toast.MakeText(this, "Deleted!", ToastLength.Short).Show();
            });

            alert.SetNegativeButton("Cancel", (senderAlert, args) => {
                Toast.MakeText(this, "Cancelled!", ToastLength.Short).Show();
            });

            Dialog dialog = alert.Create();
            dialog.Show();
            adapter.NotifyDataSetChanged();
        }

        private void Edit_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
          
            int p = e.Position;
            Intent edit_deleteIntent = new Intent(this, typeof(Edit_Del_MembersActivity));
            edit_deleteIntent.PutExtra(GetString(Resource.String.id), MemberList[p].MemberID.ToString());
            edit_deleteIntent.PutExtra(GetString(Resource.String.name), MemberList[p].Name);
            edit_deleteIntent.PutExtra(GetString(Resource.String.phoneheader), MemberList[p].Phone.ToString());
            edit_deleteIntent.PutExtra(GetString(Resource.String.emailheader), MemberList[p].Email);
            edit_deleteIntent.PutExtra(GetString(Resource.String.handicaphint), MemberList[p].Handicap.ToString());
            StartActivityForResult(edit_deleteIntent, 101);
        }

        protected override void OnActivityResult(int requestCode, [GeneratedEnum] Result resultCode, Intent data)
        {
            if (resultCode == Result.Ok && requestCode == 101)
            {             
                int memberID = int.Parse(data.GetStringExtra(GetString(Resource.String.id)));
                Member updateMember = MemberList.Find(m => m.MemberID == memberID);
                updateMember.Name = data.GetStringExtra(GetString(Resource.String.name));
                updateMember.Phone = int.Parse(data.GetStringExtra(GetString(Resource.String.phoneheader)));
                updateMember.Email = data.GetStringExtra(GetString(Resource.String.emailheader));
                updateMember.Handicap = int.Parse(data.GetStringExtra(GetString(Resource.String.handicaphint))); 
            
                adapter.NotifyDataSetChanged();
            }
        }

        private void OnMenuItem_Click(object sender, Toolbar.MenuItemClickEventArgs e)
        {
            switch (e.Item.ItemId)
            {
                case Resource.Id.search:
                    //Search icon has been clicked
                    txtSearch.Visibility = ViewStates.Visible;
                    txtSearch.RequestFocus();
                    if (mIsAnimating)
                    {
                        mIsAnimating = true;
                        txtSearch.TextChanged += Search_TextChanged;
                    }

                    if (!mAnimatedDown)
                    {
                        //Listview is up
                        MyAnimation anim = new MyAnimation(memberslistView, memberslistView.Height - txtSearch.Height);
                        anim.Duration = 500;
                        memberslistView.StartAnimation(anim);
                        anim.AnimationStart += anim_AnimationStartDown;
                        anim.AnimationEnd += anim_AnimationEndDown;
                        container.Animate().TranslationYBy(txtSearch.Height).SetDuration(500).Start();
                        txtSearch.TextChanged += Search_TextChanged;
                    }

                    else
                    {
                        //Listview is down
                        MyAnimation anim = new MyAnimation(memberslistView, memberslistView.Height + txtSearch.Height);
                        anim.Duration = 500;
                        memberslistView.StartAnimation(anim);
                        anim.AnimationStart += anim_AnimationStartUp;
                        anim.AnimationEnd += anim_AnimationEndUp;
                        container.Animate().TranslationYBy(-txtSearch.Height).SetDuration(500).Start();
                        txtSearch.TextChanged -= Search_TextChanged;
                        txtSearch.Text = "";
                       //call the list of members to get full list once search box closed.
                        IEnumerable<Member> dbmembers = dbStore.GetMembers();
                        MemberList = dbmembers.ToList();
                        adapter = new MemberListAdapter(this, MemberList);
                        memberslistView.Adapter = adapter;
                    }

                    mAnimatedDown = !mAnimatedDown;
                        break;
                case Resource.Id.add:
                    CreateMemberDialog createDialog = new CreateMemberDialog();
                    FragmentTransaction frgTxn = FragmentManager.BeginTransaction();

                    //subscribe to the event
                    createDialog.OnCreateMember += Dialog_OnCreateMember;
                    createDialog.Show(frgTxn, "Create Member");
                    break;
                case Resource.Id.edit:
                    Toast.MakeText(this, "Select an item to edit", ToastLength.Short).Show();
                    break;
                case Resource.Id.delete:
                    Toast.MakeText(this, "Long click on an item to delete it", ToastLength.Short).Show();
                    break;
                default:   
                    break;
            }
        }

        private void Dialog_OnCreateMember(object sender, CreateMemberEventArgs e)
        {
            dbStore = new DBStore();
           
            dbStore.AddMember(e.Name, e.Number, e.Email, e.Handicap);
            IEnumerable<Member> dbmembers = dbStore.GetMembers();
            //assign the database data to the list
            MemberList = dbmembers.ToList();
            adapter = new MemberListAdapter(this, MemberList);
            memberslistView.Adapter = adapter;

            adapter.NotifyDataSetChanged();
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            List<Member> searchedMembers = (from member in MemberList
                                            where member.Name.Contains(txtSearch.Text, StringComparison.OrdinalIgnoreCase) ||
                                            member.Phone.ToString().Contains(txtSearch.Text, StringComparison.OrdinalIgnoreCase) ||
                                            member.Email.Contains(txtSearch.Text, StringComparison.OrdinalIgnoreCase)
                                            select member).ToList<Member>();

            MemberList = searchedMembers; //reassign the new list to the memberlist to enable editing
            //update adapter to show any matching searches
            adapter = new MemberListAdapter(this, MemberList);
            memberslistView.Adapter = adapter;

            adapter.NotifyDataSetChanged();
        }

        //sorting data by the header row methods
        private void TxtNameHeader_Click(object sender, EventArgs e)
        {
            List<Member> filterMembers;
            if (!NameAscending)
            {
                filterMembers = (from member in MemberList
                                 orderby member.Name
                                 select member).ToList<Member>();
                //refresh the listview
                MemberList = filterMembers;
               adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;
            }
            else
            {
                filterMembers = (from member in MemberList
                                 orderby member.Name descending
                                 select member).ToList<Member>();
                //refresh the listview
                MemberList = filterMembers;
                adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;
            }
            NameAscending = !NameAscending;
        }       

        private void TxtPhoneHeader_Click(object sender, EventArgs e)
        {
            List<Member> filterMembers;
            if (!PhoneAscending)
            {
                filterMembers = (from member in MemberList
                                 orderby member.Phone
                                 select member).ToList<Member>();
                //refresh the listview
                MemberList = filterMembers;
                adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;
            }
            else
            {
                filterMembers = (from member in MemberList
                                 orderby member.Phone descending
                                 select member).ToList<Member>();
                //refresh the listview
                MemberList = filterMembers;
                adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;
            }
            PhoneAscending = !PhoneAscending;
        }

        private void TxtEmailHeader_Click(object sender, EventArgs e)
        {
            List<Member> filterMembers;
            if (!EmailAscending)
            {
                filterMembers = (from member in MemberList
                                 orderby member.Email
                                 select member).ToList<Member>();
                //refresh the listview
                MemberList = filterMembers;
                adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;
            }
            else
            {
                filterMembers = (from member in MemberList
                                 orderby member.Email descending
                                 select member).ToList<Member>();
                //refresh the listview
                MemberList = filterMembers;
                adapter = new MemberListAdapter(this, MemberList);
                memberslistView.Adapter = adapter;
            }
            EmailAscending = !EmailAscending;
        }

        //list movement methods
        void anim_AnimationEndUp(object sender, Android.Views.Animations.Animation.AnimationEndEventArgs e)
        {
            mIsAnimating = false;
            txtSearch.ClearFocus();
            InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
            inputManager.HideSoftInputFromWindow(this.CurrentFocus.WindowToken, HideSoftInputFlags.NotAlways);
        }

        void anim_AnimationEndDown(object sender, Android.Views.Animations.Animation.AnimationEndEventArgs e)
        {
            mIsAnimating = false;
        }

        void anim_AnimationStartDown(object sender, Android.Views.Animations.Animation.AnimationStartEventArgs e)
        {
            mIsAnimating = true;
            txtSearch.Animate().AlphaBy(1.0f).SetDuration(500).Start();
        }

        void anim_AnimationStartUp(object sender, Android.Views.Animations.Animation.AnimationStartEventArgs e)
        {
            mIsAnimating = true;
            txtSearch.Animate().AlphaBy(-1.0f).SetDuration(300).Start();
        }
    }
}