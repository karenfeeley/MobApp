﻿using System;
using System.Collections.Generic;
using Android.Graphics;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS
{
    class MemberListAdapter : BaseAdapter<Member>
    {
        int[] AlternatingColors;
        Context context;
        public List<Member> MemberList { get; }
        

        public MemberListAdapter(Context context, List<Member> members)
        {
            this.context = context;
            MemberList = members;
            AlternatingColors = new int[] { 0xF2F2F2, 0x008000 };

        }

        public override Java.Lang.Object GetItem(int position)
        {
            return position;
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var row = convertView;
            MemberListAdapterViewHolder holder = null;

            if (row == null)
            {
                var inflater = context.GetSystemService(Context.LayoutInflaterService).JavaCast<LayoutInflater>();
                row = inflater.Inflate(Resource.Layout.member_row_contact, parent, false);
            }
            //assigning the differing background colors to the rows
            row.SetBackgroundColor(GetColorFromInteger(AlternatingColors[position % AlternatingColors.Length]));

            var name = row.FindViewById<TextView>(Resource.Id.txtName);
            name.Text = MemberList[position].Name;
            var phone = row.FindViewById<TextView>(Resource.Id.txtPhone);
            phone.Text = MemberList[position].Phone.ToString();
            var email = row.FindViewById<TextView>(Resource.Id.txtEmail);
            email.Text = MemberList[position].Email;

            holder = new MemberListAdapterViewHolder(name, phone, email);
            row.Tag = holder;

           //alternating the textcolor for each row
            if ((position % 2) == 1)
            {
                //green background, set text white
                name.SetTextColor(Color.White);
                phone.SetTextColor(Color.White);
                email.SetTextColor(Color.White);
            }
            else
            {
                //White background, set text black
                name.SetTextColor(Color.Black);
                phone.SetTextColor(Color.Black);
                email.SetTextColor(Color.Black);
               
            }

            var cachedRow = row.Tag as MemberListAdapterViewHolder;
            cachedRow.name.Text = MemberList[position].Name;
            cachedRow.phone.Text = MemberList[position].Phone.ToString();
            cachedRow.email.Text = MemberList[position].Email;

            return row;
        }

        private Color GetColorFromInteger(int color)
        {
            return Color.Rgb(Color.GetRedComponent(color), Color.GetGreenComponent(color), Color.GetBlueComponent(color));
        }

        //Fill in count here, currently 0
        public override int Count
        {
            get
            {
                return MemberList.Count;
            }
        }

        public override Member this[int position]
        {
            get
            {
                return MemberList[position];
            }
        }
    }

    class MemberListAdapterViewHolder : Java.Lang.Object
    {
        public TextView name { get;  }
        public TextView phone { get;  }
        public TextView email { get;  }

        public MemberListAdapterViewHolder(TextView textname, TextView textphone, TextView textemail)
        {
            name = textname;
            phone = textphone;
            email = textemail;
        }
    }
}