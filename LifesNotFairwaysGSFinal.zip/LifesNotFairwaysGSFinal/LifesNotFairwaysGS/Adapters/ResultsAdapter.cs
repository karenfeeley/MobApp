﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS.Adapters
{
    class ResultsAdapter : BaseAdapter<Outings>
    {
        int[] AlternatingColors;
       
        public List<Outings> ResultsList { get; }
        Context context;

        public ResultsAdapter(Context context, List<Outings> outings)
        {
            this.context = context;
            ResultsList = outings;
            AlternatingColors = new int[] { 0xF2F2F2, 0x80bfff };
        }


        public override Java.Lang.Object GetItem(int position)
        {
            return position;
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var row = convertView;
            ResultsAdapterViewHolder holder = null;

            if (row == null)
            {
                var inflater = context.GetSystemService(Context.LayoutInflaterService).JavaCast<LayoutInflater>();
                row = inflater.Inflate(Resource.Layout.result_rowlayout, parent, false);
            }
           
            row.SetBackgroundColor(GetColorFromInteger(AlternatingColors[position % AlternatingColors.Length]));

            var course = row.FindViewById<TextView>(Resource.Id.txtCourse);
            course.Text = ResultsList[position].GolfCourse;
            var player = row.FindViewById<TextView>(Resource.Id.txtPlayers);
            player.Text = ResultsList[position].Player.ToString();
            var score = row.FindViewById<TextView>(Resource.Id.txtscore);
            score.Text = ResultsList[position].Score.ToString();

            holder = new ResultsAdapterViewHolder(course, player, score);
            row.Tag = holder;

            //alternating the textcolor for each row
            if ((position % 2) == 1)
            {
                //green background, set text white
                course.SetTextColor(Color.White);
                player.SetTextColor(Color.White);
                score.SetTextColor(Color.White);
            }
            else
            {
                //White background, set text black
                course.SetTextColor(Color.Black);
                player.SetTextColor(Color.Black);
                score.SetTextColor(Color.Black);

            }

            var cachedRow = row.Tag as ResultsAdapterViewHolder;
            cachedRow.GolfCourse.Text = ResultsList[position].GolfCourse;
            cachedRow.Player.Text = ResultsList[position].Player;
            cachedRow.Score.Text = ResultsList[position].Score.ToString();

            return row;
        }

        private Color GetColorFromInteger(int color)
        {
            return Color.Rgb(Color.GetRedComponent(color), Color.GetGreenComponent(color), Color.GetBlueComponent(color));
        }

        //Fill in count here, currently 0
        public override int Count
        {
            get
            {
                return ResultsList.Count;
            }
        }

        public override Outings this[int position]
        {
            get
            {
                return ResultsList[position];
            }
        }
    }

    class ResultsAdapterViewHolder : Java.Lang.Object
    {
        public TextView GolfCourse { get; set; }

        public TextView Player { get; set; }

        public TextView Score { get; set; }

        public ResultsAdapterViewHolder(TextView course, TextView player, TextView score)
        {
            GolfCourse = course;
            Player = player;
            Score = score;
        }
    }
}