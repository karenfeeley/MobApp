﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using LifesNotFairwaysGS.DataAccess;

namespace LifesNotFairwaysGS.Adapters
{
    class GolfCourseListAdapter : BaseAdapter<GolfCourses>
    {
        int[] AlternatingColors;
        Context context;
        public List<GolfCourses> CourseList { get; }

        public GolfCourseListAdapter(Context context, List<GolfCourses> courses)
        {
            this.context = context;
            CourseList = courses;
            AlternatingColors = new int[] { 0xF2F2F2, 0x80bfff };
        }


        public override Java.Lang.Object GetItem(int position)
        {
            return position;
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var row = convertView;
            

            if (row == null)
            {
               
                var inflater = context.GetSystemService(Context.LayoutInflaterService).JavaCast<LayoutInflater>();
               
                row = inflater.Inflate(Resource.Layout.course_rowlayout, parent, false);
            }
            //assigning the differing background colors to the rows
            row.SetBackgroundColor(GetColorFromInteger(AlternatingColors[position % AlternatingColors.Length]));

            var course = row.FindViewById<TextView>(Resource.Id.txtCourse);
            course.Text = CourseList[position].GolfCourse;
            var date = row.FindViewById<TextView>(Resource.Id.txtDate);
            date.Text = CourseList[position].EventDate;

            //alternating the textcolor for each row
            if ((position % 2) == 1)
            {
                //green background, set text white
                course.SetTextColor(Color.White);
                date.SetTextColor(Color.White);
              
            }
            else
            {
                //White background, set text black
                course.SetTextColor(Color.Black);
                date.SetTextColor(Color.Black);
               
            }

            return row;
        }

        private Color GetColorFromInteger(int color)
        {
            return Color.Rgb(Color.GetRedComponent(color), Color.GetGreenComponent(color), Color.GetBlueComponent(color));
        }

        //Fill in count here, currently 0
        public override int Count
        {
            get
            {
                return CourseList.Count;
            }
        }

        public override GolfCourses this[int position]
        {
            get
            {
                return CourseList[position];
            }
        }
    }

    class GolfCourseListAdapterViewHolder : Java.Lang.Object
    {
        //Your adapter views to re-use
        //public TextView Title { get; set; }
    }
}